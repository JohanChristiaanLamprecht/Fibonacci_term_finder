import numpy
import sys

# Function to find the number of digits in an integer value.
##################################################
def FindNumberLength(number):
    # Assign the unsigned value of the input number to a temporary calculation variable.
    n = numpy.abs(numpy.int0(number))
    # For the special case where the number is zero, set the number of digits to 1.
    if(n == 0):
        length = 1
    # Find the number of digits used in the input number.
    else:
        length = numpy.int0(0)      # Set the initial number length to 0.
        while(n > 0):               # Loop while the temporary calculation variable is greater than 0.
            length += 1                 # Increment the length variable.
            n = numpy.int0(n / 10)      # Reassign the temporary calculation integer variable to the variable divided by 10.
    # Output the calculated length.
    return length
##################################################

# Function to find the index of the first element in the Fibonacci sequence that has x number of digits.
##################################################
def fibonacci_term(number_of_digits_to_find):
    # Set up an array of length 3 to work as a window to calculate Fibonacci elements without needing to store the entire sequence in memory.
    fibonacci_window = numpy.zeros(3, numpy.int0())
    # Set current index to 0.
    current_index = numpy.int0(0)
    # Set the length of the current element in the sequence to 0.
    number_of_current_digites = numpy.int0(0)
    # Loop while the length of the current element in the Fibonacci sequence is smaller than the input length.
    while(number_of_current_digites < number_of_digits_to_find):    
        # Increment the current index.
        current_index += 1
        # Fill the Fibonacci window if it is not yet full.
        if(current_index < 3):
            fibonacci_window[current_index-1] = 1
            fibonacci_window[2] = 1
        # If the current index is at index 3 or greater, commence finding the next element in the array.
        else:
            # If the Fibonacci window is full, shift elements in the window to calculate the next element of sequence at the end of the window.
            if(current_index > 3):
                fibonacci_window[0] = fibonacci_window[1]
                fibonacci_window[1] = fibonacci_window[2]
            # Calculate the next element of sequence at the end of the window.
            fibonacci_window[2] = fibonacci_window[0] + fibonacci_window[1]
        # Call function to find the number of digits of the current sequence element.
        number_of_current_digites = FindNumberLength(fibonacci_window[2])
    # Output the current index.
    return current_index
##################################################



# Call function to find the index of the first element in the Fibonacci sequence that has x number of digits.
##################################################
print(fibonacci_term(numpy.int0(sys.argv[1])))
##################################################